# Pink Money — iPhone веб апп

## Юу багтсан бэ?
- Монгол төгрөгөөр орлого, зарлага бүртгэнэ
- Сарын орлого, зарлагын төсвөө тохируулна
- Хуримтлалын зорилго, 12 сарын төсөөлөл
- Өгөгдөл тухайн браузерын localStorage-д хадгалагдана
- JSON нөөц татах, нөөцөөс сэргээх
- PWA manifest болон service worker

## Үнэгүйгээр GitHub Pages дээр байршуулах
1. GitHub-д нэвтэрч шинэ public repository үүсгэнэ. Жишээ нэр: `pink-money`.
2. Энэ хавтас доторх бүх файлыг repository-ийн үндсэн түвшинд upload хийнэ.
3. Repository → Settings → Pages руу орно.
4. Build and deployment хэсэгт `Deploy from a branch` сонгоно.
5. Branch: `main`, folder: `/ (root)` сонгоод Save дарна.
6. Хэдэн минутын дараа `https://ТАНЫ-USERNAME.github.io/pink-money/` гэсэн HTTPS сайт үүснэ.

## iPhone дээр суулгах
1. iPhone дээр Safari нээнэ (Chrome биш).
2. Өөрийн GitHub Pages холбоос руу орно.
3. Share → Add to Home Screen → Add.
4. Pink Money дүрс үндсэн дэлгэцэд нэмэгдэнэ.

## Өгөгдлийн хадгалалт ба нууцлал
Энэ эхний хувилбар нь сервергүй. Мэдээлэл зөвхөн тухайн iPhone-ийн Safari/browser storage-д хадгалагдана. Өөр төхөөрөмжтэй автоматаар синк хийхгүй. Safari website data-г устгах, төхөөрөмж солих үед мэдээлэл алдагдаж болзошгүй тул Settings хэсгийн "Нөөц татах"-ыг үе үе ашиглаж, JSON файлаа iCloud Drive эсвэл Files-д хадгална.

GitHub repository-г public байлгасан ч хувийн санхүүгийн мэдээлэл repository руу илгээгдэхгүй; харин аппын HTML/код нийтэд харагдана. Нууц үг эсвэл банкны нэвтрэх мэдээлэл бүү оруулаарай.
